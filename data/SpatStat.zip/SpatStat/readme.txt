Wards: There are a total of 44 electoral wards in the City of Toronto	

	GEO_ID = unique geographic identifier
	NAME = Name of the Ward with corresponding ward number
        SCODE_NAME = Ward Number
	LCODE_NAME = Ward Number and the community council area it is in (N,S, E or W)
	TYPE_DESC = Ward
	TYPE_CODE = City Ward








